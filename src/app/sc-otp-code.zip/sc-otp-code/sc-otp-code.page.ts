import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sc-otp-code',
  templateUrl: './sc-otp-code.page.html',
  styleUrls: ['./sc-otp-code.page.scss'],
})
export class ScOtpCodePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
